﻿function altera_altura() {
    var altura = $('#box_content2').css('height'); //varivel para guardar altura atual do box


    // é tamanho original
    if (altura == '85px') { // se sim
        $('#box_content2').css('height', '320px');
        $('#item4').css('height', '320px');
        $('#abre_fecha').attr('src', 'images/seta_fecha.jpg');
    }
    else {// senão
        $('#box_content2').css('height', '85px');
        $('#item4').css('height', '85px');
        $('#abre_fecha').attr('src','images/seta_abre.jpg');
    }
}