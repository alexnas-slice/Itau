﻿
$(document).ready(function () {

    var empresa;
    var ambiente;
    var plataforma;
    var sessao;
    var ip;
    var porta;

});




function ValidaBusca(){

    empresa = $('#ddl_empresa').val();
    ambiente = $('#ddl_ambiente').val();
    plataforma = $('#ddl_plataforma').val();
    sessao = $('#txt_id').val().toUpperCase();

    if (empresa == "" || ambiente == "" || plataforma == "" || sessao == "") {
        alert("Contém um ou mais campos não preenchidos!");
        return false;
    }

}


function ValidaProsseguir(empresa, ambiente, plataforma, sessao, ip, porta, device_name, Secure, Hllapi, modelo) {
    SSL = false;
    

    if (empresa == "" || ambiente == "" || plataforma == "" || ip == "" || porta == "") {
        alert("Contém um ou mais campos não preenchidos!");
        return false;
    }

    if (Secure == "on") {
        SSL = true;
    }

    openPage("W2H - " + sessao + " " + ambiente + " " + empresa + " " + plataforma, sessao, Hllapi, ip, porta, modelo, window.location, SSL, SSL, plataforma, device_name);
    

}

// funcção para validação da remoção a partir da inserção dos dados e click do btn_remover -- botão dentro do formulario
function ValidaRemover() {

    empresa = $('#ddl_empresa').val();
    ambiente = $('#ddl_ambiente').val();
    plataforma = $('#ddl_plataforma').val();
    sessao = $('#txt_id').val();

    if (empresa == "" || ambiente == "" || plataforma == "" || sessao == "") {
        alert("Contém um ou mais campos não preenchidos!");
        return false;
    }

}

// função para validação a partir do click no aDelete -- botão ao lado das sessões criadas
function ValidaRemoverBotao(nome) {
    var resposta = confirm("Deseja realmente excluir a sessão: " + nome + "?"); // variavel de resposta --deseja realmente deletar
    if(resposta == false) { // não deseja deletar
        return false;
    }
}

function ValidaPrinter(empresa, ambiente, plataforma, sessao, device_name) {

    if (empresa == "" || ambiente == "" || plataforma == "") {
        alert("Contém um ou mais campos não preenchidos!");
        return false;
    }

    openPrinter(device_name, plataforma, window.location);
}