﻿window.onbeforeunload = function () {
    $.ajax({
        url: '/action.aspx',
        dataType: 'json',
        async: false,
        data: { 'parameter': $("#tidSecao").val(), 'action': 'TerminateSession' }
    });
};

function update_time() {
    $.ajax({
        url:'/action.aspx',
        dataType: 'json',
        async: false,
        data: {'parameter': $("#tidSecao").val(), 'action': 'UpdateTime'}
    });
}

//função para verificar se a página ainda se mantém aberta
function estaAberta(){
    window.setTimeout(function(){
            $.ajax({
            url:'/action.aspx',
            dataType: 'json',
            data: {'parameter': $("#tidSecao").val(), 'action': 'UpdateTime'}
        }); 
        estaAberta();
    }, 300000);
}