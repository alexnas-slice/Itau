﻿function openPage(Titulo, Sourcename, Shortname, Ip, Porta, Terminal, idioma, security, sslenable, Plataforma, DeviceName) { // abre a pagina do terminal
     vresult = $("#hidWinUser").val();
    $.ajax({
        url: "action.aspx",
        dataType: "json",
        data: { "parameter": Plataforma + ";" + Ip + ";" + vresult, "action": "AddSession" },
        success: function (data) {
            window.location = "https://onwebcorp.itau/w2hlegacy/emulacao/itau/config_dinamico/" + Plataforma + "Dinamico.asp?p_titulo=" + Titulo + "&p_sourcename=" + Sourcename + "&p_shortname=" + Shortname + "&p_IP=" + Ip + "&p_DeviceName=" + DeviceName + "&p_porta=" + Porta + "&p_terminal=" + Terminal + "&p_Idioma=" + idioma + "&p_SecurityOn=" + security + "&p_SSLEnabled=" + sslenable + "&idsessao=" + data.id + "&portal=s";
        }
    });
    return true;
}

function openPrinter(Printer, Plataforma, idioma) {
    if (Plataforma == "MF") {
        window.location = "https://onwebcorp.itau/w2hlegacy/emulacao/Itau/config_dinamico/MFP_Itau.asp?p_sourcename=MFP_IMP_ITAU&p_IP=172.23.32.253;172.23.32.29&p_DeviceName=" + Printer + "&p_porta=50024&p_terminal=2&p_Idioma=" + idioma + "&p_SecurityOn=true||false||false||false||false&p_SSLEnabled=true&p_titulo=MFP_IMP_ITAU";
    }
    if (Plataforma == "AS") {
        window.location = "https://onwebcorp.itau/w2hlegacy/emulacao/Itau/config_dinamico/AS400Printer.asp?p_titulo=MFP_IMP_AS400&p_sourcename=" + Printer + "&p_IP=" + Printer + "&p_Idioma=" + idioma;
    }

}

function openBacen(Titulo, Sourcename, Shortname, Ip, Porta, Terminal, idioma, security, sslenable, Plataforma, DeviceName) { // abre a pagina do terminal
    vresult = $("#hidWinUser").val();
    $.ajax({
        url: "action.aspx",
        dataType: "json",
        data: { "parameter": Plataforma + ";" + Ip + ";" + vresult, "action": "AddSession" },
        success: function (data) {
            window.location = "https://onwebcorp.itau/w2hlegacy/emulacao/itau/config_dinamico/Bacen.asp?p_titulo=" + Titulo + "&p_sourcename=" + Sourcename + "&p_shortname=" + Shortname + "&p_IP=" + Ip + "&p_DeviceName=" + DeviceName + "&p_porta=" + Porta + "&p_terminal=" + Terminal + "&p_Idioma=" + idioma + "&p_SecurityOn=" + security + "&p_SSLEnabled=" + sslenable + "&idsessao=" + data.id + "&portal=s";
        }
    });
    return true;
}